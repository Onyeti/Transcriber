//
//  PlaybackView.swift
//  Transcriber
//
//  Created by Tolulope Osinubi on 7/5/25.
//

import Foundation
import SwiftUI
import AVFoundation

struct PlaybackView: View {
    
    // Represents the recorded session with audio and transcript
    let session: Sessions
    
    @State private var audioPlayer: AVAudioPlayer?
    @State private var isPlaying = false
    @State private var isShowingShareSheet = false
    @State private var showCopyAlert = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                Text("Playback for Session")
                    .font(.title)
                
                Text(session.timestamp.formatted(date: .abbreviated, time: .standard))
                    .foregroundStyle(.gray)

                // Play/Pause Button
                Button(action: {
                    if isPlaying {
                        stopPlayback()
                    } else {
                        startPlayback()
                    }
                }) {
                    Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.blue)
                }

                // If transcript is available, show it with Copy and Share actions
                if let transcript = session.transcript, !transcript.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Transcript:")
                            .font(.headline)

                        Text(transcript)
                            .font(.body)
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(8)

                        HStack {
                            Button(action: {
                                UIPasteboard.general.string = transcript
                                showCopyAlert = true
                            }) {
                                Label("Copy", systemImage: "doc.on.doc")
                            }
                            .alert("Copied to Clipboard", isPresented: $showCopyAlert) {
                                Button("OK", role: .cancel) {}
                            }
                            
                            Spacer()
                            
                            Button(action: {
                                isShowingShareSheet = true
                            }) {
                                Label("Share", systemImage: "square.and.arrow.up")
                            }
                        }
                        .padding(.top, 8)
                    }
                    .padding()
                } else {
                    Text("No transcript available.")
                        .foregroundColor(.gray)
                        .padding()
                }
            }
            .padding()
        }
        .onDisappear {
            // Ensure playback stops when user leaves the view
            stopPlayback()
        }
        .sheet(isPresented: $isShowingShareSheet) {
            // Present the share sheet with the transcript as a shareable item
            if let transcript = session.transcript {
                ShareSheet(activityItems: [transcript])
            }
        }
    }
    
    // Starts audio playback using AVAudioPlayer
    func startPlayback() {
        guard let path = session.audioFilePath else {
            print("No audio file path found")
            return
        }
        let url = URL(fileURLWithPath: path)
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
            isPlaying = true
        } catch {
            print("Failed to play audio: \(error.localizedDescription)")
        }
    }
    
    // Stops audio playback
    func stopPlayback() {
        audioPlayer?.stop()
        isPlaying = false
    }
}

// Wrapper for presenting the iOS Share Sheet in SwiftUI
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
