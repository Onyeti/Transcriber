//
//  SessionList.swift
//  Transcriber
//
//  Created by Tolulope Osinubi on 7/5/25.
//

import SwiftUI
import SwiftData
import AVFoundation

struct SessionList: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Sessions.timestamp, order: .forward) private var allSessions: [Sessions]

    @State private var searchText = ""

    // Filtered list based on search
    var filteredSessions: [Sessions] {
        if searchText.isEmpty {
            return allSessions
        } else {
            return allSessions.filter { session in
                session.transcript?.localizedCaseInsensitiveContains(searchText) == true
            }
        }
    }

    var body: some View {
        VStack {
            // Search bar for filtering transcripts
            TextField("Search transcripts...", text: $searchText)
                .padding(10)
                .background(Color(.systemGray6))
                .cornerRadius(10)
                .padding([.horizontal, .top])

            // List of all matching sessions
            List {
                ForEach(filteredSessions, id: \.id) { session in
                    if let originalIndex = allSessions.firstIndex(where: { $0.id == session.id }) {
                        NavigationLink(destination: PlaybackView(session: session)) {
                            VStack(alignment: .leading) {
                                Text("Session \(originalIndex + 1)")
                                    .font(.headline)
                                Text(session.timestamp.formatted(date: .abbreviated, time: .standard))
                                    .font(.subheadline)
                                    .foregroundStyle(.gray)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
                .onDelete(perform: deleteSession) // Swipe to delete
            }
            .listStyle(.insetGrouped)
        }
        .navigationTitle("Session History")
    }

    // Delete selected sessions from the model
    private func deleteSession(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                let sessionToDelete = filteredSessions[index]
                modelContext.delete(sessionToDelete)
            }
        }
    }

    init() {}
}

#Preview {
    SessionList()
}
