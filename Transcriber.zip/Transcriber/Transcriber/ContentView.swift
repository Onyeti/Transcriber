//
//  ContentView.swift
//  Transcriber
//
//  Created by Tolulope Osinubi on 7/5/25.
//

import SwiftUI
import SwiftData
import AVFoundation
import Speech

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var items: [Sessions]
    
    @State private var audioRecorder: AVAudioRecorder?
    @State private var isRecording = false
    @State private var showSavedPopup = false
    
    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                Spacer()
                
                // Main microphone button (toggle recording/pause)
                Button(action: {
                    if isRecording {
                        pauseRecording()
                    } else {
                        startRecording()
                    }
                }) {
                    Image(systemName: isRecording ? "mic.circle.fill" : "mic.circle")
                        .resizable()
                        .frame(width: 200, height: 200)
                        .foregroundStyle(.blue)
                }
                
                Spacer()
                
                // Playback control buttons (pause/start, stop)
                HStack {
                    Spacer()
                    Spacer()
                    
                    Button(action: {
                        if isRecording {
                            pauseRecording()
                        } else {
                            startRecording()
                        }
                    }) {
                        Image(systemName: isRecording ? "pause.fill" : "play.fill")
                            .resizable()
                            .frame(width: 30, height: 30)
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        stopRecording()
                    }) {
                        Image(systemName: "stop.fill")
                            .resizable()
                            .frame(width: 30, height: 30)
                    }
                    
                    Spacer()
                    Spacer()
                }
                
                Spacer()
                
                Text("Press the stop button when you are finished recording.")
                    .multilineTextAlignment(.center)
                
                Spacer()
                
                // Bottom navigation: Info and Session History
                HStack {
                    Spacer()
                    
                    NavigationLink(destination: InfoPage()) {
                        Image(systemName: "info.circle.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .padding(.trailing, 10)
                            .foregroundStyle(.black)
                    }
                    
                    NavigationLink("Session History") {
                        SessionList()
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .padding()

            // Ask for recording and transcription permissions when view appears
            .onAppear {
                requestPermission()
            }
            
            // Popup when recording is saved
            .overlay(
                    Group {
                        if showSavedPopup {
                            Text("Recording saved")
                                .padding()
                                .background(Color.black.opacity(0.8))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                                .transition(.move(edge: .bottom).combined(with: .opacity))
                                .zIndex(1)
                        }
                    },
                    alignment: .bottom
                )
                .animation(.easeInOut(duration: 0.3), value: showSavedPopup)
        }
    }
    
    // Requests microphone and speech recognition permission
    func requestPermission() {
        if #available(iOS 17.0, *) {
            AVAudioApplication.requestRecordPermission { allowed in
                if !allowed {
                    print("User denied microphone access")
                }
            }
        } else {
            AVAudioSession.sharedInstance().requestRecordPermission { allowed in
                if !allowed {
                    print("User denied microphone access")
                }
            }
        }

        SFSpeechRecognizer.requestAuthorization { authStatus in
            switch authStatus {
            case .authorized:
                print("Speech recognition authorized")
            default:
                print("Speech recognition not authorized")
            }
        }
    }
    
    // Creates a file URL for saving the audio recording
    func getAudioFileURL() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDirectory = paths[0]
        let filename = "session-\(Date().timeIntervalSince1970).m4a"
        return docDirectory.appendingPathComponent(filename)
    }
    
    // Starts a new audio recording
    func startRecording() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playAndRecord, mode: .default)
            try session.setActive(true)
            
            let url = getAudioFileURL()
            let settings = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 12000,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]
            
            audioRecorder = try AVAudioRecorder(url: url, settings: settings)
            audioRecorder?.record()
            isRecording = true
        } catch {
            print("Failed to start recording: \(error.localizedDescription)")
        }
    }
    
    // Pauses the current recording
    func pauseRecording() {
        audioRecorder?.pause()
        isRecording = false
    }
    
    // Stops recording and begins transcription
    func stopRecording() {
        audioRecorder?.stop()
        isRecording = false
            
        guard let url = audioRecorder?.url else { return }
            
        transcribeAudio(from: url) { transcript in
            DispatchQueue.main.async {
                self.saveSession(with: url, transcript: transcript)
                self.audioRecorder = nil
                self.showSavedPopup = true
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.showSavedPopup = false
                }
            }
        }
    }
    
    // Saves a new session into SwiftData
    func saveSession(with url: URL, transcript: String?) {
        withAnimation {
            let newSession = Sessions(timestamp: Date(), audioFilePath: url.path, transcript: transcript)
            modelContext.insert(newSession)
        }
    }
    
    // Transcribes audio file using SFSpeechRecognizer in 30 second segments
    func transcribeAudio(from url: URL, completion: @escaping (String?) -> Void) {
        let recognizer = SFSpeechRecognizer()
        guard recognizer?.isAvailable == true else {
            print("Speech recognizer not available")
            completion(nil)
            return
        }

        let asset = AVURLAsset(url: url)
        
        Task {
            do {
                let duration = try await asset.load(.duration)
                let totalSeconds = CMTimeGetSeconds(duration)
                let segmentDuration: Double = 30
                let segmentCount = Int(ceil(totalSeconds / segmentDuration))
                
                var fullTranscript = ""
                var currentIndex = 0

                func processNextSegment() {
                    guard currentIndex < segmentCount else {
                        completion(fullTranscript)
                        return
                    }

                    let startSeconds = Double(currentIndex) * segmentDuration
                    let endSeconds = min(Double(currentIndex + 1) * segmentDuration, totalSeconds)
                    let start = CMTime(seconds: startSeconds, preferredTimescale: 600)
                    let duration = CMTime(seconds: endSeconds - startSeconds, preferredTimescale: 600)
                    let range = CMTimeRange(start: start, duration: duration)

                    Task {
                        await exportAudioSegment(asset: asset, timeRange: range) { segmentURL in
                            guard let segmentURL = segmentURL else {
                                print("Failed to export segment \(currentIndex)")
                                currentIndex += 1
                                processNextSegment()
                                return
                            }

                            let request = SFSpeechURLRecognitionRequest(url: segmentURL)
                            recognizer?.recognitionTask(with: request) { result, error in
                                if let result = result {
                                    if result.isFinal {
                                        fullTranscript += result.bestTranscription.formattedString + "\n\n"
                                        currentIndex += 1
                                        processNextSegment()  // proceed only after final result
                                    }
                                } else if let error = error {
                                    print("Error transcribing segment \(currentIndex): \(error.localizedDescription)")
                                    currentIndex += 1
                                    processNextSegment()
                                }
                            }
                        }
                    }
                }

                processNextSegment()
            } catch {
                print("Failed to load asset duration: \(error.localizedDescription)")
                completion(nil)
            }
        }
    }
    
    // Exports a segment of an audio asset to a temporary file
    @MainActor
    func exportAudioSegment(asset: AVAsset, timeRange: CMTimeRange, completion: @escaping (URL?) -> Void) {
        guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            completion(nil)
            return
        }

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("m4a")

        exporter.timeRange = timeRange

        Task {
            do {
                try await exporter.export(to: outputURL, as: .m4a)
                completion(outputURL)
            } catch {
                print("Export failed with error: \(error.localizedDescription)")
                completion(nil)
            }
        }
    }
}

#Preview {
    ContentView()
        .modelContainer(for: Sessions.self, inMemory: true)
}
