//
//  InfoPage.swift
//  Transcriber
//
//  Created by Tolulope Osinubi on 7/5/25.
//

import SwiftUI

struct InfoPage: View {
    var body: some View {
        Spacer()
        Spacer()
        Text("Automatically transcribe audio with the click of a button!")
            .multilineTextAlignment(.center)
        Spacer()
        Text("Search through your saved recordings or delete a saved recording by swiping right!")
            .multilineTextAlignment(.center)
        Spacer()
        Spacer()
    }
}

#Preview {
    InfoPage()
}
