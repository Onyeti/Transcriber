//
//  Sessions.swift
//  Transcriber
//
//  Created by Tolulope Osinubi on 7/5/25.
//

import Foundation
import SwiftData
import AVFoundation

// The Sessions model represents a single recording session.
@Model
final class Sessions: Identifiable {
    var id: UUID = UUID()
    var timestamp: Date
    var audioFilePath: String?
    var transcript: String?

    init(timestamp: Date, audioFilePath: String? = nil, transcript: String? = nil) {
        self.timestamp = timestamp
        self.audioFilePath = audioFilePath
        self.transcript = transcript
    }
}
