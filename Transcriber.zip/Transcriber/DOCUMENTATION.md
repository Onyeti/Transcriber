Transcriber – iOS Voice Recording and Transcription App


----Architecture Overview----

High-Level Design:
Built with SwiftUI and SwiftData using an MVVM (Model-View-ViewModel) approach.
Keeps UI reactive with @State and @Query for databinding.
Handles audio logic directly inside ContentView.swift.
Breaks large transcription into segments to prevent memory issues.

Layer Responsibilities
Model: Defines data structure with Sessions.swift.
View: Handles UI and user interactions with ContentView.swift, SessionList.swift.
Logic: Audio recording, transcription, and permission handling built into views.

                                                
----Audio System Design----

Components Used:
AVAudioRecorder for capturing audio.
AVAudioSession for configuring input/output.
SFSpeechRecognizer for transcription.

Audio Routing:
Audio session set to .playAndRecord to support input + output.
Compatible with Bluetooth headsets, AirPods, and built-in mic.

Handling Interruptions (Planned):
Currently does not handle interruptions like calls or Siri.
Can be improved using AVAudioSession.interruptionNotification.

                                                
----Data Model Design----

SwiftData Schema
Defines a Sessions model with:
id: UUID
timestamp: Date of recording
audioFilePath: Local path to saved .m4a file
transcript: Optional transcription string

Storage Strategy:
Audio files saved to app's documents directory.
Sessions stored persistently with SwiftData.
Transcriptions stored as plain text for easy search and display.

                                                
----Performance Optimizations----
Transcription is segmented in 30-second intervals for memory efficiency.
Uses lazy List rendering and @Query for fast UI updates.
Filters sessions by transcript using case-insensitive search.


----App Features----

Large mic button for starting and pausing recordings.
Play, pause, and stop controls with animated icons.
Full transcription of recorded audio using Apple’s Speech framework.
Chunked transcription for long recordings to avoid API failures.
Saved sessions with timestamped history.
Built-in search bar to find sessions by transcript content.
SwiftData-based persistent storage.
Recording confirmation popup when recording ends.
Export/share functionality

                                                
----Known Issues & Improvements----

No audio route change handling:
Not aware when switching from mic to headphones.
Needs AVAudioSession.routeChangeNotification.

No interruption handling:
Doesn’t resume if interrupted by calls or system events.
Add AVAudioSession.interruptionNotification.

All logic in views:
View layer handles too much responsibility.
Refactor to use ViewModels for testability.

No background audio support:
Recording stops when app is backgrounded.
Enable background audio in capabilities.

No duplicate detection:
Repeated or near-identical recordings not flagged.

                                                
----Suggested Enhancements----

iCloud sync for cross-device storage.
Live transcription as user speaks.
AI-generated summaries of each session.

                                                
----Frameworks & Tools Used----

SwiftUI – Declarative UI framework.
SwiftData – Lightweight, modern persistence layer.
AVFoundation – Audio recording and playback.
Speech Framework – Speech-to-text capabilities.

                                                
----App Permissions Required----

NSMicrophoneUsageDescription
Reason: Record audio sessions.

NSSpeechRecognitionUsageDescription
Reason: Transcribe speech using Apple’s speech recognizer.

